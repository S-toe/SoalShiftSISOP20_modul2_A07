

CREATE TABLE `backset` (
  `url` varchar(100) NOT NULL,
  `sessiontime` varchar(4) DEFAULT NULL,
  `footer` varchar(50) DEFAULT NULL,
  `themesback` varchar(2) DEFAULT NULL,
  `responsive` varchar(2) DEFAULT NULL,
  `namabisnis1` tinytext NOT NULL,
  `batas` int(5) NOT NULL,
  PRIMARY KEY (`url`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO backset VALUES("http://localhost/indo2","100","Aplikasi Indotory","2","0","IndoTory V3","10");



CREATE TABLE `barang` (
  `kode` varchar(20) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `hargabeli` int(11) DEFAULT NULL,
  `hargajual` int(11) DEFAULT NULL,
  `keterangan` varchar(200) DEFAULT NULL,
  `kategori` varchar(20) DEFAULT NULL,
  `terjual` int(11) DEFAULT NULL,
  `terbeli` int(11) DEFAULT NULL,
  `sisa` int(11) DEFAULT NULL,
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(50) NOT NULL,
  `brand` text NOT NULL,
  `avatar` varchar(300) NOT NULL,
  PRIMARY KEY (`kode`),
  KEY `no` (`no`),
  KEY `jenis` (`kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=latin1;

INSERT INTO barang VALUES("0002","Asus Zenfone Max Pro M2 4GB","32000000","35000000","rak B2 No. M464","Smartphone","7","24","23","42","IDWARE0002","Nokia","dist/upload/tde1.jpg");
INSERT INTO barang VALUES("0003","Nokia 6600 Jadul","200000","500000","rak No apa..","Smartphone","5","29","24","43","IDWARE0003","Nokia","dist/upload/tde1.jpg");
INSERT INTO barang VALUES("0004","Tas Herpes A762V","8000000","10000000","tas hitam rak 78","Tas","4","234","240","44","IDWARE0004","Louis Vuitton","dist/upload/download.jpg");
INSERT INTO barang VALUES("0005","Tas LV Black A888","18000000","20000000","tas bekas","Tas","3","24","25","45","IDWARE1001","Louis Vuitton","dist/upload/download.jpg");
INSERT INTO barang VALUES("0006","Nokia 3110","200000","400000","Hp Jadul bekas","Smartphone","0","258","258","46","IDWARE1000","Nokia","dist/upload/tde1.jpg");
INSERT INTO barang VALUES("0007","Dompet Pria LV B82","15000000","2000000","dompet pria hitam rak 98","Tas","0","0","0","47","IDWARE1002","Louis Vuitton","dist/upload/download.jpg");
INSERT INTO barang VALUES("0009","barang tes","200000","16000000","11","Smartphone","0","0","0","49","IDWARE1004","Samsung","dist/upload/tde1.jpg");
INSERT INTO barang VALUES("0010","barang 1","1","1","","Smartphone","0","0","0","50","","Samsung","dist/upload/download.jpg");
INSERT INTO barang VALUES("0011","barang 3","200000","16000000","111","Smartphone","0","0","0","51","IDWARE1005","Samsung","dist/upload/");
INSERT INTO barang VALUES("0012","TAS LV White 878","16500000","170000000","diletakan di rak: 878A","Tas","0","0","0","53","IDWARE1006","Samsung","dist/upload/download.jpg");
INSERT INTO barang VALUES("0013","Aplikasi Indotory","499000","500000","diletakan di rak mana","Smartphone","1","14","13","54","IDWARE1007","Samsung","dist/upload/indo pro Plus.png");
INSERT INTO barang VALUES("0014","Kertas Paper One 70 A4","35000","40000","Kertas Paper One 70 A4 Kualitas Premium","Kertas","73","2000","1989","55","121215864001","Paper One","dist/upload/a4-70gr.jpg");



CREATE TABLE `bayar` (
  `nota` varchar(20) NOT NULL,
  `tglbayar` date DEFAULT NULL,
  `bayar` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `kembali` int(11) DEFAULT NULL,
  `keluar` int(11) DEFAULT NULL,
  `kasir` varchar(100) DEFAULT NULL,
  `no` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`nota`),
  KEY `no` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=latin1;

INSERT INTO bayar VALUES("0006","2019-12-02","99999999","32000000","67999999","31000000","admin","125");
INSERT INTO bayar VALUES("0007","2020-01-02","999999","500000","499999","200000","admin","126");
INSERT INTO bayar VALUES("0008","2020-01-02","999777666","35000000","964777666","32000000","admin","127");
INSERT INTO bayar VALUES("0009","2020-01-02","100000000","36000000","64000000","33500000","admin","128");
INSERT INTO bayar VALUES("0010","2020-01-02","20008000","20000000","8000","16000000","admin","129");
INSERT INTO bayar VALUES("0011","2020-01-02","999999999","35000000","964999999","32000000","admin","130");
INSERT INTO bayar VALUES("0012","2020-01-06","100000000","70000000","30000000","64000000","admin","131");
INSERT INTO bayar VALUES("0013","2020-01-06","999999","500000","499999","200000","admin","132");
INSERT INTO bayar VALUES("0014","2020-01-09","2200000","2180000","20000","1670000","admin","133");
INSERT INTO bayar VALUES("0015","2020-01-14","300000","0","0","0","admin","134");
INSERT INTO bayar VALUES("0016","2020-01-14","200000","0","0","0","admin","135");



CREATE TABLE `beli` (
  `nota` varchar(20) NOT NULL,
  `tglbeli` date DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `supplier` varchar(20) DEFAULT NULL,
  `kasir` varchar(100) DEFAULT NULL,
  `keterangan` varchar(200) DEFAULT NULL,
  `no` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`nota`),
  KEY `no` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

INSERT INTO beli VALUES("0003","2020-01-02","2147483647","0001","admin","bayar belakangan","20");
INSERT INTO beli VALUES("0004","2020-01-06","998000","0001","admin","dibayar dimuka","21");
INSERT INTO beli VALUES("0005","2020-01-09","35000000","","admin","","22");
INSERT INTO beli VALUES("0006","2020-01-14","0","0002","admin","","23");



CREATE TABLE `brand` (
  `kode` varchar(20) NOT NULL,
  `nama` varchar(30) DEFAULT NULL,
  `no` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`kode`),
  KEY `no4` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO brand VALUES("0001","Samsung","7");
INSERT INTO brand VALUES("0003","Louis Vuitton","8");
INSERT INTO brand VALUES("0004","Nokia","12");
INSERT INTO brand VALUES("0005","Paper One","13");



CREATE TABLE `buy` (
  `nota` varchar(20) NOT NULL,
  `tglsale` date DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `supplier` varchar(200) DEFAULT NULL,
  `kasir` varchar(100) DEFAULT NULL,
  `keterangan` varchar(250) DEFAULT NULL,
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`nota`),
  KEY `no` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

INSERT INTO buy VALUES("0001","2019-12-02","147483647","0001","admin"," ","14","dibayar");
INSERT INTO buy VALUES("0002","2020-01-02","482800000","0002","admin"," ","15","dibayar");
INSERT INTO buy VALUES("0003","2020-01-02","31000000","0001","admin"," ","16","dibayar");
INSERT INTO buy VALUES("0004","2020-01-02","600000","0002","admin"," ","17","belum");
INSERT INTO buy VALUES("0005","2020-01-06","600000","0001","admin"," bla bla bla","18","belum");
INSERT INTO buy VALUES("0006","2020-01-09","35000000","0003","admin"," Test Beli ok 2","19","belum");



CREATE TABLE `chmenu` (
  `userjabatan` varchar(20) NOT NULL,
  `menu1` varchar(1) DEFAULT '0',
  `menu2` varchar(1) DEFAULT '0',
  `menu3` varchar(1) DEFAULT '0',
  `menu4` varchar(1) DEFAULT '0',
  `menu5` varchar(1) DEFAULT '0',
  `menu6` varchar(1) DEFAULT '0',
  `menu7` varchar(1) DEFAULT '0',
  `menu8` varchar(1) DEFAULT '0',
  `menu9` varchar(1) DEFAULT '0',
  `menu10` varchar(1) DEFAULT '0',
  `menu11` varchar(1) DEFAULT '0',
  PRIMARY KEY (`userjabatan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO chmenu VALUES("admin","5","5","5","5","5","5","5","5","5","5","5");
INSERT INTO chmenu VALUES("demo","0","0","0","0","5","5","0","0","0","0","");



CREATE TABLE `data` (
  `nama` varchar(100) DEFAULT NULL,
  `tagline` varchar(100) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `notelp` varchar(20) DEFAULT NULL,
  `signature` varchar(255) DEFAULT NULL,
  `avatar` varchar(150) DEFAULT NULL,
  `no` int(11) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO data VALUES("Nama Toko Anda","Toko Online Keren","Jalan Menuju Sukses No.1 Kel.Suka Makmur kec.Maju Jaya Provinsi Sehat Selalu Negara Hidup Bahagia","62999999999","Thank you for Shopping with us
-- ini bisa di edit--","dist/img/logo.png","0");



CREATE TABLE `info` (
  `nama` varchar(50) DEFAULT NULL,
  `avatar` varchar(100) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `isi` text DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO info VALUES("iam Admin gantent","dist/upload/avatar.png","2020-01-02","<h1>Indotory v3 Pro Plus<small></small>:</h1><p>hanya beli di tokopedia.com/warungebook<br><br>fitur dibawah ini tidak ada di yg versi basic</p><p><br>Fitur Pro:<br><br>-Scan Barcode saat jualan</p><p>-Scan barcode untuk tambah stok<br></p><p>-Scan Barcode untuk stok keluar</p><p>-Cetak barcode, cetak Invoice, cetak Struk dg logo<br><br>Fitur Plus:<br>-Detail barang plus gambar barang, mutasi<br>-Detail User isinya ttg user, penjualan user,pembelian user,aktivitas user</p><p>-Stok Alert , tentukan batas minimal stok barang, jika ada yg kurang dr stok minimal maka akan muncul daftar barangnya<br><br><br></p><p><br></p>","1");
INSERT INTO info VALUES("iam Admin gantent","dist/upload/avatar.png","2020-01-02","<h1>Indotory v3 Pro Plus<small></small>:</h1><p>hanya beli di tokopedia.com/warungebook<br><br>fitur dibawah ini tidak ada di yg versi basic</p><p><br>Fitur Pro:<br><br>-Scan Barcode saat jualan</p><p>-Scan barcode untuk tambah stok<br></p><p>-Scan Barcode untuk stok keluar</p><p>-Cetak barcode, cetak Invoice, cetak Struk dg logo<br><br>Fitur Plus:<br>-Detail barang plus gambar barang, mutasi<br>-Detail User isinya ttg user, penjualan user,pembelian user,aktivitas user</p><p>-Stok Alert , tentukan batas minimal stok barang, jika ada yg kurang dr stok minimal maka akan muncul daftar barangnya<br><br><br></p><p><br></p>","1");



CREATE TABLE `invoicebeli` (
  `nota` varchar(20) NOT NULL,
  `kode` varchar(200) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `harga` int(11) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `hargaakhir` int(11) DEFAULT NULL,
  `no` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`nota`,`kode`),
  KEY `barang` (`nama`),
  KEY `no5_2` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=188 DEFAULT CHARSET=latin1;

INSERT INTO invoicebeli VALUES("0001","0002","Asus Zenfone Max Pro M2 4GB","32000000","24","768000000","177");
INSERT INTO invoicebeli VALUES("0001","0003","Nokia 6600 Jadul","200000","27","5400000","178");
INSERT INTO invoicebeli VALUES("0001","0004","Tas Herpes A762V","8000000","234","1872000000","179");
INSERT INTO invoicebeli VALUES("0002","0005","Tas LV Black A888","18000000","24","432000000","180");
INSERT INTO invoicebeli VALUES("0002","0006","Nokia 3110","200000","254","50800000","181");
INSERT INTO invoicebeli VALUES("0003","0001","Samsung Note 10","15500000","2","31000000","182");
INSERT INTO invoicebeli VALUES("0004","0003","Nokia 6600 Jadul","200000","1","200000","183");
INSERT INTO invoicebeli VALUES("0004","0006","Nokia 3110","200000","2","400000","184");
INSERT INTO invoicebeli VALUES("0005","0003","Nokia 6600 Jadul","200000","1","200000","186");
INSERT INTO invoicebeli VALUES("0005","0006","Nokia 3110","200000","2","400000","185");
INSERT INTO invoicebeli VALUES("0006","0014","Kertas Paper One 70 A4","35000","1000","35000000","187");



CREATE TABLE `invoicejual` (
  `nota` varchar(20) NOT NULL,
  `kode` varchar(200) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `harga` int(11) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `hargaakhir` int(11) DEFAULT NULL,
  `no` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`nota`,`kode`),
  KEY `barang` (`nama`),
  KEY `no5_2` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=175 DEFAULT CHARSET=latin1;

INSERT INTO invoicejual VALUES("0004","0002","Asus Zenfone Max Pro M2 4GB","35000000","2","70000000","167");
INSERT INTO invoicejual VALUES("0004","0005","Tas LV Black A888","20000000","1","20000000","168");
INSERT INTO invoicejual VALUES("0005","0003","Nokia 6600 Jadul","500000","2","1000000","169");
INSERT INTO invoicejual VALUES("0006","0002","Asus Zenfone Max Pro M2 4GB","35000000","1","35000000","171");
INSERT INTO invoicejual VALUES("0006","0004","Tas Herpes A762V","10000000","2","20000000","170");
INSERT INTO invoicejual VALUES("0007","0014","Kertas Paper One 70 A4","40000","19","760000","172");
INSERT INTO invoicejual VALUES("0008","0014","Kertas Paper One 70 A4","40000","12","480000","173");
INSERT INTO invoicejual VALUES("0009","0005","Tas LV Black A888","20000000","1","20000000","174");



CREATE TABLE `jabatan` (
  `kode` varchar(20) NOT NULL,
  `nama` varchar(20) DEFAULT NULL,
  `no` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`kode`),
  KEY `no` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

INSERT INTO jabatan VALUES("0001","admin","28");
INSERT INTO jabatan VALUES("0002","demo","33");



CREATE TABLE `kategori` (
  `kode` varchar(20) NOT NULL,
  `nama` varchar(30) DEFAULT NULL,
  `no` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`kode`),
  KEY `no4` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO kategori VALUES("0001","Smartphone","7");
INSERT INTO kategori VALUES("0002","Tas","10");
INSERT INTO kategori VALUES("0003","Kertas","11");



CREATE TABLE `mutasi` (
  `namauser` varchar(50) NOT NULL,
  `tgl` date NOT NULL,
  `kodebarang` varchar(10) NOT NULL,
  `sisa` int(10) NOT NULL,
  `jumlah` int(10) NOT NULL,
  `kegiatan` varchar(100) NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=latin1;

INSERT INTO mutasi VALUES("admin","2020-01-02","0001","200","200","membeli barang tanpa invoice","0003","106","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0002","24","24","membeli barang memakai invoice","0001","107","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0003","27","27","membeli barang memakai invoice","0001","108","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0004","234","234","membeli barang memakai invoice","0001","109","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0005","24","24","membeli barang memakai invoice","0002","110","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0006","254","254","membeli barang memakai invoice","0002","111","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0001","191","2","membeli barang memakai invoice","0003","112","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0001","189","-2","menjual barang memakai struk","0006","113","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0002","26","2","menjual barang memakai invoice","0004","114","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0005","25","1","menjual barang memakai invoice","0004","115","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0003","29","2","menjual barang memakai invoice","0005","116","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0003","26","1","membeli barang memakai invoice","0004","117","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0006","256","2","membeli barang memakai invoice","0004","118","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0004","236","1","menambah stok dgn barcode scan","tidak tersedia","119","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0004","238","1","menambah stok dgn barcode scan","tidak tersedia","120","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0004","240","1","menambah stok dgn barcode scan","tidak tersedia","121","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0003","24","1","mengeluarkan stok dgn barcode scan","tidak tersedia","122","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0003","22","1","mengeluarkan stok dgn barcode scan","tidak tersedia","123","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0003","21","-1","menjual barang memakai struk","0007","124","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0002","25","-1","menjual barang memakai struk","0008","125","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0004","242","2","menjual barang memakai invoice","0006","126","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0001","188","-1","menjual barang memakai struk","0009","127","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0005","24","-1","menjual barang memakai struk","0009","128","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0004","240","-2","menjual barang memakai struk","0010","129","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-02","0002","24","-1","menjual barang memakai struk","0011","130","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-06","0002","22","-2","menjual barang memakai struk","0012","131","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-06","0013","11","-11","menyesuaikan stok secara manual","tidak tersedia","132","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-06","0013","13","2","membeli barang tanpa invoice","0004","133","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-06","0006","258","2","membeli barang memakai invoice","0005","134","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-06","0003","26","1","membeli barang memakai invoice","0005","135","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-06","0003","25","-1","menjual barang memakai struk","0013","136","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-06","0002","23","1","menjual barang memakai invoice","0006","137","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-09","0014","1000","1000","membeli barang tanpa invoice","0005","138","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-09","0014","2000","1000","membeli barang memakai invoice","0006","139","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-09","0014","1958","-42","menjual barang memakai struk","0014","140","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-09","0003","24","-1","menjual barang memakai struk","0014","141","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-09","0014","1977","19","menjual barang memakai invoice","0007","142","berhasil");
INSERT INTO mutasi VALUES("admin","2020-01-09","0014","1989","12","menjual barang memakai invoice","0008","143","berhasil");
INSERT INTO mutasi VALUES("admin","2020-02-14","0005","25","1","menjual barang memakai invoice","0009","144","berhasil");



CREATE TABLE `operasional` (
  `kode` varchar(20) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `biaya` int(11) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `kasir` varchar(20) DEFAULT NULL,
  `no` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`kode`),
  KEY `no` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO operasional VALUES("0001","bayar gaji Des-2019","2020-01-06","4000000","bla bla bla","admin","2");
INSERT INTO operasional VALUES("0002","Biaya Listrik","2019-12-26","100000","bayar listrik dengan kode 00000","admin","3");



CREATE TABLE `pelanggan` (
  `kode` varchar(20) NOT NULL,
  `tgldaftar` date DEFAULT NULL,
  `nama` varchar(25) DEFAULT NULL,
  `alamat` varchar(70) DEFAULT NULL,
  `nohp` varchar(20) DEFAULT NULL,
  `no` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`kode`),
  KEY `no3` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO pelanggan VALUES("0003","2019-12-26","PT ETERNAL Youth","Jalan kaki pegal, kelurahan jarang masuk kecamatan datang telat","321334","9");
INSERT INTO pelanggan VALUES("0004","2020-01-01","Andika","jalan Cukong no 87","08757577775555","10");



CREATE TABLE `sale` (
  `nota` varchar(20) NOT NULL,
  `tglsale` date DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `pelanggan` varchar(200) DEFAULT NULL,
  `kasir` varchar(100) DEFAULT NULL,
  `keterangan` varchar(250) DEFAULT NULL,
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(11) NOT NULL,
  PRIMARY KEY (`nota`),
  KEY `no` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

INSERT INTO sale VALUES("0001","2019-12-02","20000000","0004","admin"," ","24","dibayar");
INSERT INTO sale VALUES("0004","2020-01-02","90000000","0003","admin","silahkan  transfer ke:
BCA: 999-000-999-1
mandiri: 9-0000-0000-0001 ","22","dibayar");
INSERT INTO sale VALUES("0005","2020-01-02","1000000","0004","admin"," ","23","belum");
INSERT INTO sale VALUES("0006","2020-01-06","55000000","0003","admin"," di transfer ke bla bla","25","dibayar");
INSERT INTO sale VALUES("0007","2020-01-09","760000","0004","admin"," test","26","dibayar");
INSERT INTO sale VALUES("0008","2020-01-09","480000","0004","admin"," test 2","27","dibayar");
INSERT INTO sale VALUES("0009","2020-02-14","20000000","0003","admin"," ","28","dibayar");



CREATE TABLE `supplier` (
  `kode` varchar(20) NOT NULL,
  `tgldaftar` date DEFAULT NULL,
  `nama` varchar(25) DEFAULT NULL,
  `alamat` varchar(70) DEFAULT NULL,
  `nohp` varchar(20) DEFAULT NULL,
  `no` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`kode`),
  KEY `no3` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO supplier VALUES("0001","2016-12-21","PT Susah Bersama","Jl Kelapa gading Boulevard Blok Qj5 no 50, Kelurahan Kelapa Kecamatan ","0219390303","2");
INSERT INTO supplier VALUES("0002","2020-01-02","CV Setia Kawan","Jalan Pelabuhan No 27 kelurahan tanjung duren kecamatan Grogol Jakarta","0219238892","9");
INSERT INTO supplier VALUES("0003","2020-01-09","PT. Riau Andalan Kertas","Test","081212125546","10");



CREATE TABLE `transaksibeli` (
  `nota` varchar(20) NOT NULL,
  `kode` varchar(20) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `harga` int(11) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `hargaakhir` int(11) DEFAULT NULL,
  `no` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`nota`,`kode`),
  KEY `no` (`no`),
  KEY `username` (`kode`),
  KEY `kdbarang` (`harga`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

INSERT INTO transaksibeli VALUES("0004","0013","Aplikasi Indotory","499000","2","998000","27");
INSERT INTO transaksibeli VALUES("0005","0014","Kertas Paper One 70 A4","35000","1000","35000000","28");



CREATE TABLE `transaksimasuk` (
  `nota` varchar(20) NOT NULL,
  `kode` varchar(200) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `harga` int(11) DEFAULT NULL,
  `hargabeli` int(11) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `hargaakhir` int(11) DEFAULT NULL,
  `hargabeliakhir` int(11) DEFAULT NULL,
  `no` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`nota`,`kode`),
  KEY `barang` (`nama`),
  KEY `no5_2` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=239 DEFAULT CHARSET=latin1;

INSERT INTO transaksimasuk VALUES("0006","0001","Samsung Note 10","16000000","15500000","2","32000000","31000000","228");
INSERT INTO transaksimasuk VALUES("0007","0003","Nokia 6600 Jadul","500000","200000","1","500000","200000","229");
INSERT INTO transaksimasuk VALUES("0008","0002","Asus Zenfone Max Pro M2 4GB","35000000","32000000","1","35000000","32000000","230");
INSERT INTO transaksimasuk VALUES("0009","0001","Samsung Note 10","16000000","15500000","1","16000000","15500000","231");
INSERT INTO transaksimasuk VALUES("0009","0005","Tas LV Black A888","20000000","18000000","1","20000000","18000000","232");
INSERT INTO transaksimasuk VALUES("0010","0004","Tas Herpes A762V","10000000","8000000","2","20000000","16000000","233");
INSERT INTO transaksimasuk VALUES("0011","0002","Asus Zenfone Max Pro M2 4GB","35000000","32000000","1","35000000","32000000","234");
INSERT INTO transaksimasuk VALUES("0012","0002","Asus Zenfone Max Pro M2 4GB","35000000","32000000","2","70000000","64000000","235");
INSERT INTO transaksimasuk VALUES("0013","0003","Nokia 6600 Jadul","500000","200000","1","500000","200000","236");
INSERT INTO transaksimasuk VALUES("0014","0003","Nokia 6600 Jadul","500000","200000","1","500000","200000","238");
INSERT INTO transaksimasuk VALUES("0014","0014","Kertas Paper One 70 A4","40000","35000","42","1680000","1470000","237");



CREATE TABLE `user` (
  `userna_me` varchar(20) NOT NULL,
  `pa_ssword` varchar(70) DEFAULT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `nohp` varchar(20) DEFAULT NULL,
  `tgllahir` date DEFAULT NULL,
  `tglaktif` date DEFAULT NULL,
  `jabatan` varchar(20) DEFAULT NULL,
  `avatar` varchar(100) DEFAULT NULL,
  `no` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`userna_me`),
  KEY `no` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("admin","90b9aa7e25f80cf4f64e990b78a9fc5ebd6cecad","iam Admin gantent","    jalan menuju sukses no 1 kelurahan kaya raya kecamatan makmur jaya provinsi panjang umur","019101911","2020-01-01","2016-10-08","admin","dist/upload/avatar.png","1");
INSERT INTO user VALUES("demo","a69681bcf334ae130217fea4505fd3c994f5683f","demo12231","demo demo demo","321334","0011-11-11","2020-01-01","demo","dist/upload/index.jpg","2");
INSERT INTO user VALUES("demo1","a69681bcf334ae130217fea4505fd3c994f5683f","demo","demo demo demo","321334","0011-11-11","0001-11-11","admin","bootstrap/dist/upload/index.jpg","23");
INSERT INTO user VALUES("superadmin","095fd63ec4594cc8117cce148c660d64ba02adab","supervisor","demo demo demo","321334","0111-11-11","0001-11-11","admin","bootstrap/dist/upload/world-contries.jpg","26");

