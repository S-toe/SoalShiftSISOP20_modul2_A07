 <head>
<meta http-equiv="refresh" content="0; url=index" />
</head>

	<body>
<table width="100%" align="center" cellspacing="0">
  <tr>
    <td height="500px" align="center" valign="middle"><img src="img/load.gif">
  </tr>
</table>
</body>
 